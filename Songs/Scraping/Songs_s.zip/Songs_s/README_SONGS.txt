time_signature: Time signature of the key; how many beats per measure.
energy: A number that ranges from 0 to 1, representing how energetic The Echo Nest thinks this song is. 
danceability: A number that ranges from 0 to 1, representing how danceable The Echo Nest thinks this song is. 
tempo: the overall estimated tempo of a track in beats per minute (BPM).  In musical terminology, tempo is the 
speed or pace of a given piece and derives directly from the average beat durati
duration:Length of the song, in seconds. 
key:The key that The Echo Nest believes the song is in. Key signatures start at 0 (C) and ascend the chromatic scale. In this case, a key of 1 represents a song in D-flat
liveness:Detects the presence of an audience in the recording. The more confident that the track is live, the closer to 1.0 the attribute value.
speechiness:Detects the presence of spoken words in a track. The more exclusively speech-like the recording (e.g. talk show, audio book, poetry), the closer to 1.0 the attribute value. 
instrumentalness:between 0 and 1
loudness: The overall loudness of a track in decibels (dB). 
acousticness:a measure of how acoustic vs. electric a song is. A value close to 1 indicates that the song is mostly recorded with acoustic instruments and non-modified vocals, while a value close to zero indicates that the song has many electric instruments such as as electric guitars and synths. 
valence:a measure of the emotional content of a song. A value close to one indicates a positive emotion, while a value close to zero is a negative emotion. 
song_hotttnesss: (not sure), but I think it is the popularity of the song: from 0 to 1, 1 being very popular
song_name: The name of the song
artist_name: The name of the artist
genre: if it is classical, rock, pop, jazz,metal...